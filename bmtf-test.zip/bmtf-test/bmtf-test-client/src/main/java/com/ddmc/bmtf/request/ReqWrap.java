package com.ddmc.bmtf.request;

/**
 * @author: liujingui
 * @date: 2023/6/12 6:57 下午
 * @description: 请求DTO统一封装接口，在领域实现中用统一标准提供DTO参数
 */
public interface ReqWrap {

}