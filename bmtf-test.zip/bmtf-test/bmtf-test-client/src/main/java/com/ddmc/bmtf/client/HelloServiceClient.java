package com.ddmc.bmtf.client;

import com.ddmc.bmtf.dto.HelloRespDTO;
import com.ddmc.bmtf.dto.HelloReqDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(value = "bmtf-test-service", path = "/api")
public interface HelloServiceClient {

    @PostMapping("/hello")
    HelloRespDTO hello(@RequestBody HelloReqDTO helloReq);

}
