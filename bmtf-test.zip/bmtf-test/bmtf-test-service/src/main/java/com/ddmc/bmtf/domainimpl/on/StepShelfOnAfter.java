package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepAfterBO;
import com.ddmc.bmtf.domainimpl.StepShelfAfter;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnAfter<BO extends ShelfStepAfterBO, BC extends ShelfContext> extends StepShelfAfter<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC>{

    @Override
    public void response(BO bo, BC bc) {
        log.info("StepShelfOnAfter#response,time:{}", System.currentTimeMillis());
    }
}
