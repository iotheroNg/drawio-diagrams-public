package com.ddmc.bmtf.template.face.shelf;


import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

@FunctionalInterface
public interface StepGetOnOrOffTheShelvesFace {

    StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace();
}
