package com.ddmc.bmtf.template.face.shelf;

import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

@FunctionalInterface
public interface StepGetOnOrOffTheShelvesFaceProcess {

    StepOnOrOffTheShelvesFaceProcess stepOnOrOffTheShelvesFaceProcess();
}
