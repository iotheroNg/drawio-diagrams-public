package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepShelfBO;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

public abstract class StepShelfShelf<BO extends ShelfStepShelfBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFace<BO, BC> {
}
