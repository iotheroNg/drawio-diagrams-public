package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepShelfBO;
import com.ddmc.bmtf.domainimpl.StepShelfShelf;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnShelf<BO extends ShelfStepShelfBO, BC extends ShelfContext> extends StepShelfShelf<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC> {


    @Override
    public <REQ extends ReqWrap> void genBO(REQ req, BC bc) {
        log.info("com.ddmc.bmtf.domain.impl.on.StepShelfOnShelf.genBO,time:{}", System.currentTimeMillis());
    }
}
