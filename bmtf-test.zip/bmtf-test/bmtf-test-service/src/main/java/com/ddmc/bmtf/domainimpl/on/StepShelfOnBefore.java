package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepBeforeBO;
import com.ddmc.bmtf.domainimpl.StepShelfBefore;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnBefore<BO extends ShelfStepBeforeBO, BC extends ShelfContext> extends StepShelfBefore<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC> {

    @Override
    public <REQ extends ReqWrap> void genBO(REQ req, BC bc) {
        super.genBO(req, bc);
        log.info("com.ddmc.bmtf.domain.impl.on.StepShelfOnBefore.genBO,time:{}", System.currentTimeMillis());
    }

    @Override
    public void checkData(BO bo, BC bc) {
        log.info("com.ddmc.bmtf.domain.impl.on.StepShelfOnBefore.checkData,time:{}", System.currentTimeMillis());
    }
}
