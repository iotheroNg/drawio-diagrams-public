package com.ddmc.bmtf.template.step.shelf.process;

import com.ddmc.bmtf.model.ability.AAbilityFacade;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

@AAbilityFacade
public interface StepOnOrOffTheShelvesFaceProcess<BO extends IBusinessObject, BC extends IBOExeContext> extends StepOnOrOffTheShelvesFace<BO, BC>{
}
