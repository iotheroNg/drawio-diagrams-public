package com.ddmc.bmtf.common.constant;

import com.ddmc.bmtf.constant.SystemConstant;

/**
 * 业务常量
 * @author huangjiyang
 */
public class BizConstant {

    /**
     * b --> biz 业务
     */
    public static final String BIZ_MAI_CAI = "b.maiCai";

    /**
     * p --> product 产品
     */
    public static final String PRODUCT_PIN_TUAN = "p.pinTuan";

    /**
     * FD --> fieldDomain
     * 属性域
     */
    public static final String FD_BALANCE = "fd.balance";

    /**
     * FD --> fieldDomain
     * 属性域
     */
    public static final String FD_TICKET = "fd.ticket";

    public static final String FD_TICKET_BLANK = "fd.ticketBlank";


    public static final int FIELD_DOMAIN_PRIORITY_BALANCE = 4001;
    public static final int FIELD_DOMAIN_PRIORITY_TICKET = 4002;

    /**
     * s --> scenario 场景
     */
    public static final String SCENARIO_LG_940 = "s.lg.9.4.0";

    public static final String SCENARIO_EQ_940 = "s.eq.9.4.0";

    public static final String SCENARIO_LT_940 = "s.lt.9.4.0";

    public static final String SCENARIO_ADD_ORDER = "addOrder";

    public static final String SCENARIO_CHECK_ORDER = "checkOrder";

    public static String fdBalance(){
        return FD_BALANCE + SystemConstant.T_S_SPLIT_CODE + SCENARIO_ADD_ORDER;
    }

    public static String fdTicket(){
        return FD_TICKET + SystemConstant.T_S_SPLIT_CODE + SCENARIO_ADD_ORDER;
    }
}
