package com.ddmc.bmtf;

import com.ddmc.bmtf.annotation.BmtfProxyScan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class}, scanBasePackages = {"com.ddmc"})
@Slf4j
@BmtfProxyScan(value = {"com.ddmc.bmtf"})
public class App {

    public static void main(String[] args) {
        try {
            SpringApplication.run(App.class, args);
        } catch (Exception e) {
            log.error("service start error", e);
        }
    }
}
