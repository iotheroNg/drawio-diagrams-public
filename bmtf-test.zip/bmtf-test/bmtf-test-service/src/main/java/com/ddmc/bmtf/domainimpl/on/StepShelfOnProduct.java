package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepShelfBO;
import com.ddmc.bmtf.domainimpl.StepShelfShelf;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnProduct<BO extends ShelfStepShelfBO, BC extends ShelfContext> extends StepShelfShelf<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC> {

    @Override
    public BO bo(BC bc) {
        return super.bo(bc);
    }

    @Override
    public void checkData(BO bo, BC bc) {
        log.info("com.ddmc.bmtf.domain.impl.on.StepShelfOnProduct.checkData,time:{}", System.currentTimeMillis());
    }
}
