package com.ddmc.bmtf.template.config.shelf;

import com.ddmc.bmtf.common.constant.BoIdentityConstant;
import com.ddmc.bmtf.common.constant.BoScenesConstant;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFaceProcess;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;
import com.ddmc.bmtf.template.step.shelf.process.impl.StepOnOrOffTheShelvesFaceProcessFactory;

import javax.annotation.Resource;

@ATemplateExt(codes = {BoIdentityConstant.DDMC}, type = TemplateType.BUSINESS, scenario = BoScenesConstant.SHELF_ON)
public class BizTemplateDDMCShelfOn implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFaceProcess {

    @Resource
    private StepOnOrOffTheShelvesFaceProcessFactory factory;

    @Override
    public StepOnOrOffTheShelvesFaceProcess stepOnOrOffTheShelvesFaceProcess() {
        return factory;
    }
}
