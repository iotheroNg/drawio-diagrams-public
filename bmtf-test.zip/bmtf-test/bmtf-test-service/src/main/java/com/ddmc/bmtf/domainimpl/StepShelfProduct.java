
package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepProductBO;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

public abstract class StepShelfProduct<BO extends ShelfStepProductBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFace<BO, BC> {
}