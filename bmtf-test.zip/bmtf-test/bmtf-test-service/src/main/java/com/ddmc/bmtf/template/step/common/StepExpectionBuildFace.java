package com.ddmc.bmtf.template.step.common;

import com.ddmc.bmtf.model.ability.IAbilityFacade;
import com.ddmc.bmtf.model.execute.ExecuteStrategyAllMatch;
import com.ddmc.bmtf.model.ext.AExtensionPoint;
import com.ddmc.bmtf.model.ext.ExtensionPointType;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.model.process.IProcessStep;


public interface StepExpectionBuildFace<BO extends IBusinessObject, BC extends IBOExeContext> extends IProcessStep<BO, BC>, IAbilityFacade {
    String PREFIX = "COMMON-";

    String EXCEPTION = "EXCEPTION";

    @AExtensionPoint(code = PREFIX + EXCEPTION, name = "异常处理", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS, skipZeroImpl = true)
    default void exception(BO req, BC bc) {

    }
}
