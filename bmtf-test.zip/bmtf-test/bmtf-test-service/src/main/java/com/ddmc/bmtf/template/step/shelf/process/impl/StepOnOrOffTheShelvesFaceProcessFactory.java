package com.ddmc.bmtf.template.step.shelf.process.impl;

import com.ddmc.bmtf.model.ability.AAbility;
import com.ddmc.bmtf.model.ability.AAbilityInstance;
import com.ddmc.bmtf.model.execute.BlankAbilityTarget;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.runtime.ability.AbstractAbility;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

import javax.annotation.Resource;

@AAbility
@AAbilityInstance
public class StepOnOrOffTheShelvesFaceProcessFactory extends AbstractAbility<BlankAbilityTarget, StepOnOrOffTheShelvesFaceProcess> implements StepOnOrOffTheShelvesFaceProcess {

    @Resource
    private StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace;

    @Override
    public void genBO(ReqWrap reqWrap, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.genBO(reqWrap, iboExeContext);
    }

    /**
     * 步骤2：检查各域数据
     *
     * @param iBusinessObject
     * @param iboExeContext
     */
    @Override
    public void checkData(IBusinessObject iBusinessObject, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.checkData(iBusinessObject, iboExeContext);
    }

    /**
     * 步骤3：上下架核心处理逻辑
     *
     * @param req
     * @param iboExeContext
     */
    @Override
    public void shelfConfig(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.shelfConfig(req, iboExeContext);
    }

    /**
     * 步骤3：上下架核心处理逻辑
     *
     * @param req
     * @param iboExeContext
     */
    @Override
    public void doDB(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.doDB(req, iboExeContext);
    }

    @Override
    public void groupProductHandler(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.groupProductHandler(req, iboExeContext);
    }

    @Override
    public void sendMQ(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.sendMQ(req, iboExeContext);
    }

    @Override
    public void addOperationLog(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.addOperationLog(req, iboExeContext);
    }

    @Override
    public void exception(IBusinessObject req, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.exception(req, iboExeContext);
    }

    @Override
    public void response(IBusinessObject iBusinessObject, IBOExeContext iboExeContext) {
        stepOnOrOffTheShelvesFace.response(iBusinessObject, iboExeContext);
    }
}
