package com.ddmc.bmtf.template.step.shelf;

import com.ddmc.bmtf.model.ability.AAbilityFacade;
import com.ddmc.bmtf.model.ability.IAbilityFacade;
import com.ddmc.bmtf.model.execute.ExecuteStrategyAllMatch;
import com.ddmc.bmtf.model.ext.AExtensionPoint;
import com.ddmc.bmtf.model.ext.ExtensionPointType;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.model.process.IProcessStep;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.step.common.StepExpectionBuildFace;
import com.ddmc.bmtf.template.step.common.StepResponseBuildFace;

@AAbilityFacade
public interface StepOnOrOffTheShelvesFace<BO extends IBusinessObject, BC extends IBOExeContext> extends IProcessStep<BO, BC>, IAbilityFacade, StepExpectionBuildFace<BO, BC>, StepResponseBuildFace<BO, BC> {
    String PREFIX = "THE_SHELVES-";

    String GEN_BO = "GEN_BO";

    /**
     * 步骤1：解析入参 2. 生成业务对象BO
     *
     * @param req
     * @param bc
     * @param <REQ>
     */
    @AExtensionPoint(code = PREFIX + GEN_BO, name = "生成业务对象BO", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS, skipZeroImpl = true)
    default <REQ extends ReqWrap> void genBO(REQ req, BC bc) {

    }

    String CHECK_DATA = "CHECK_DATA";

    /**
     * 步骤2：检查各域数据
     *
     * @param bo
     * @param bc
     */
    @AExtensionPoint(code = PREFIX + CHECK_DATA, name = "检查各域数据", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void checkData(BO bo, BC bc) {

    }

    String SHELF_CONFIG = "SHELF_CONFIG";

    /**
     * 步骤3：上下架核心处理逻辑
     *
     * @param bo
     * @param bc
     * @param <REQ>
     */
    @AExtensionPoint(code = PREFIX + SHELF_CONFIG, name = "上下架核心处理逻辑", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void shelfConfig(BO bo, BC bc) {

    }

    String DO_DB = "DO_DB";

    /**
     * 步骤3：上下架核心处理逻辑
     *
     * @param bo
     * @param bc
     * @param <REQ>
     */
    @AExtensionPoint(code = PREFIX + DO_DB, name = "操作db", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void doDB(BO bo, BC bc) {

    }

    String GROUP_PRODUCT_HANDLER = "GROUP_PRODUCT_HANDLER";

    @AExtensionPoint(code = PREFIX + DO_DB, name = "组合品下架特殊逻辑处理", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void groupProductHandler(BO bo, BC bc) {

    }

    String SEND_MQ = "SEND_MQ";

    @AExtensionPoint(code = PREFIX + SEND_MQ, name = "发生消息处理", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void sendMQ(BO bo, BC bc) {

    }

    String ADD_OPERATION_LOG = "ADD_OPERATION_LOG";

    @AExtensionPoint(code = PREFIX + ADD_OPERATION_LOG, name = "日志记录", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS_OBJECT, skipZeroImpl = true)
    default void addOperationLog(BO bo, BC bc) {

    }
}
