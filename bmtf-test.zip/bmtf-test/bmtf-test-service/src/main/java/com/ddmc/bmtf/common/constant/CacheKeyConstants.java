package com.ddmc.bmtf.common.constant;

/**
 *
 */
public class CacheKeyConstants {

    private static String PREFIX="bmtf:service:";

    public static final String DEMO = PREFIX + "demo";


}