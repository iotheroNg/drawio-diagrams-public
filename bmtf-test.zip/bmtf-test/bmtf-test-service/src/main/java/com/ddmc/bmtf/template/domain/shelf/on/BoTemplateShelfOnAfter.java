package com.ddmc.bmtf.template.domain.shelf.on;

import com.ddmc.bmtf.constant.DefaultExtPriorityConstant;
import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepAfterBO;
import com.ddmc.bmtf.domainimpl.on.StepShelfOnAfter;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

import javax.annotation.Resource;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.AFTER;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;

/**
 * @Description: 前置步骤域模版
 **/
@ATemplateExt(codes = {AFTER}, scenario = SHELF_ON, type = TemplateType.BUSINESS_OBJECT, templatePriority = DefaultExtPriorityConstant.PRIORITY_COVERED)
public class BoTemplateShelfOnAfter implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFace {

    @Resource
    private StepShelfOnAfter stepShelfOnAfter;

    @Override
    public StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace() {
        return new StepOnOrOffTheShelvesFaceProcess() {

            @Override
            public void response(IBusinessObject iBusinessObject, IBOExeContext iboExeContext) {
                stepShelfOnAfter.response((ShelfStepAfterBO) iBusinessObject, (ShelfContext) iboExeContext);
            }
        };
    }
}