package com.ddmc.bmtf.template.domain.shelf.on;

import com.ddmc.bmtf.constant.DefaultExtPriorityConstant;
import com.ddmc.bmtf.domainimpl.on.StepShelfOnPrice;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

import javax.annotation.Resource;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.PRICE;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;


@ATemplateExt(codes = {PRICE}, scenario = SHELF_ON, type = TemplateType.BUSINESS_OBJECT, templatePriority = DefaultExtPriorityConstant.PRIORITY_COVERED)
public class BoTemplateShelfOnPrice implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFace {

    @Resource
    private StepShelfOnPrice stepShelfOnPrice;
    @Override
    public StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace() {
        return stepShelfOnPrice;
    }
}
