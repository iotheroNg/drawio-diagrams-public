package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepAfterBO;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

public abstract class StepShelfAfter<BO extends ShelfStepAfterBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFace<BO, BC> {
}
