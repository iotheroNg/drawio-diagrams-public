package com.ddmc.bmtf.service.impl;

import com.ddmc.bmtf.model.execute.BizInstanceId;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.service.ShelfStepService;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author: liujingui
 * @date: 2023/5/22 10:57 上午
 * @description: 各领域执行流程节点
 */
@Slf4j
@Component
public class ShelfStepServiceImpl implements ShelfStepService {

    @Resource
    private StepOnOrOffTheShelvesFaceProcess stepOnOrOffTheShelvesFaceProcess;

    @Override
    public void doStep(ReqWrap reqWrap, IBOExeContext bc, BizInstanceId<Object> bizInstanceId) {
        stepOnOrOffTheShelvesFaceProcess.genBO(reqWrap, bc);
        stepOnOrOffTheShelvesFaceProcess.checkData(null,bc);
        stepOnOrOffTheShelvesFaceProcess.shelfConfig(null,bc);
        stepOnOrOffTheShelvesFaceProcess.doDB(null,bc);
        stepOnOrOffTheShelvesFaceProcess.groupProductHandler(null,bc);
        stepOnOrOffTheShelvesFaceProcess.sendMQ(null,bc);
        stepOnOrOffTheShelvesFaceProcess.addOperationLog(null,bc);
        stepOnOrOffTheShelvesFaceProcess.response(null,bc);
    }
}