package com.ddmc.bmtf.common.constant;

public class BoIdentityConstant {
    public static final String DDMC = "ddmc";
}
