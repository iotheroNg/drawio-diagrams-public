package com.ddmc.bmtf.common.exception;


public class ServiceException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private Integer code;

    public ServiceException(Integer code) {
        super();
        this.code = code;
    }

    public ServiceException(Integer code, Throwable ex) {
        super(ex);
        this.code = code;
    }

    public ServiceException(Integer code, String message, Throwable ex) {
        super(message, ex);
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

}
