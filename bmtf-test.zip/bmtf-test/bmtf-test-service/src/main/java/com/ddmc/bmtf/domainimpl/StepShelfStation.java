package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepStationBO;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;

public abstract class StepShelfStation<BO extends ShelfStepStationBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFaceProcess<BO, BC> {
}
