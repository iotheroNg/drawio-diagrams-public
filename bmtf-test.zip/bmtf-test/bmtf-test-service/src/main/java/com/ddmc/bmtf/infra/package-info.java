/**
 * 基础设施层，涉及 db, cache, 第三方rpc调用。同时负责外部数据到domain entity的转换
 */
package com.ddmc.bmtf.infra;