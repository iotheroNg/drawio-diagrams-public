package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepBeforeBO;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.process.StepOnOrOffTheShelvesFaceProcess;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class StepShelfBefore<BO extends ShelfStepBeforeBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFace<BO, BC> {

    /**
     * 步骤1：解析入参 2. 生成业务对象BO
     *
     * @param req
     * @param bc
     */
    @Override
    public <REQ extends ReqWrap> void genBO(REQ req, BC bc) {
       log.info("StepShelfBefore#genBO，time:" + System.currentTimeMillis());
    }
}
