package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepPriceBO;
import com.ddmc.bmtf.domainimpl.StepShelfPrice;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnPrice<BO extends ShelfStepPriceBO, BC extends ShelfContext> extends StepShelfPrice<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC> {

    @Override
    public void checkData(BO bo, BC bc) {
        log.info("com.ddmc.bmtf.domain.impl.on.StepShelfOnPrice.checkData,time:{}", System.currentTimeMillis());
    }
}
