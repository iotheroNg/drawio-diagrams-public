package com.ddmc.bmtf.domainimpl;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepPriceBO;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class StepShelfPrice<BO extends ShelfStepPriceBO, BC extends ShelfContext> implements StepOnOrOffTheShelvesFace<BO, BC> {


    @Override
    public <REQ extends ReqWrap> void genBO(REQ req, BC bc) {
        log.info("com.ddmc.bmtf.domain.impl.StepShelfPrice.genBO,time:{}", System.currentTimeMillis());
    }
}
