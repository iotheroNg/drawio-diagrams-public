package com.ddmc.bmtf.controller;

import com.ddmc.bmtf.common.constant.BoIdentityConstant;
import com.ddmc.bmtf.common.constant.BoScenesConstant;
import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.dto.HelloRespDTO;
import com.ddmc.bmtf.model.execute.BizInstanceId;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.runtime.invoke.BizInstanceIdHolder;
import com.ddmc.bmtf.service.ShelfStepService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api", produces = {MediaType.APPLICATION_JSON_VALUE})
public class HelloController {
    @Autowired
    private ShelfStepService shelfStepService;

    @GetMapping("/bmtf")
    public HelloRespDTO bmtf() {
        // 设置业务身份上下文
        BizInstanceId bizInstanceId = BizInstanceId.of(BoIdentityConstant.DDMC ,"DDMC");
        bizInstanceId.scenario(BoScenesConstant.SHELF_ON);
        BizInstanceIdHolder.save(bizInstanceId);
        ShelfContext addOrderContext = new ShelfContext();
        IBOExeContext.genBOofDefaultValue(addOrderContext);
        shelfStepService.doStep(null, addOrderContext, bizInstanceId);
        return new HelloRespDTO("hello bmtf");
    }
}
