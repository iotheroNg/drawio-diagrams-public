package com.ddmc.bmtf.template.step.common;

import com.ddmc.bmtf.model.ability.IAbilityFacade;
import com.ddmc.bmtf.model.execute.ExecuteStrategyAllMatch;
import com.ddmc.bmtf.model.ext.AExtensionPoint;
import com.ddmc.bmtf.model.ext.ExtensionPointType;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.model.process.IProcessStep;

public interface StepResponseBuildFace<BO extends IBusinessObject, BC extends IBOExeContext> extends IProcessStep<BO, BC>, IAbilityFacade {
    String PREFIX = "COMMON-";
    String RESPONSE = "RESPONSE";

    @AExtensionPoint(code = PREFIX + RESPONSE, name = "构建响应对象", executeStrategy = ExecuteStrategyAllMatch.class, type = ExtensionPointType.BUSINESS, skipZeroImpl = true)
    default void response(BO bo, BC bc) {

    }
}
