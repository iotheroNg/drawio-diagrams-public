package com.ddmc.bmtf.domain.shelf;

import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import lombok.Data;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Data
public class ShelfContext implements IBOExeContext  {

    /******************用于对该类里的BO生成默认对象*******************/
    private static final Map<Class<? extends IBusinessObject>, List<Method>> boSetMethodMap
            = Collections.unmodifiableMap(IBOExeContext.findBOSetMethod(ShelfContext.class));


    private ShelfStepBeforeBO stepBeforeBO;

    private ShelfStepProductBO stepProductBO;

    /**
     * 由子类返回boSet方法的缓存Map
     *
     * @return
     */
    @Override
    public <BO extends IBusinessObject, BC extends IBOExeContext> Map<Class<BO>, List<Method>> boSetMethodCacheMap() {
        return (Map) boSetMethodMap;
    }
}
