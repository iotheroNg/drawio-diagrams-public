package com.ddmc.bmtf.domainimpl.on;

import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepStationBO;
import com.ddmc.bmtf.domainimpl.StepShelfStation;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StepShelfOnStation<BO extends ShelfStepStationBO, BC extends ShelfContext> extends StepShelfStation<BO, BC> implements StepOnOrOffTheShelvesFace<BO, BC> {
}
