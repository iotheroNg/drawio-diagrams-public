package com.ddmc.bmtf.domain.shelf;

import com.ddmc.bmtf.model.process.IBusinessObject;
import lombok.Data;

@Data
public class ShelfStepAfterBO implements IBusinessObject {


}
