package com.ddmc.bmtf.infra.repository.dao.mapper;

import com.ddmc.bmtf.infra.repository.dao.UserDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface UserMapper {

    UserDO getUserById(int id);


}
