package com.ddmc.bmtf.common.util;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.ConfigService;
import org.apache.commons.lang3.StringUtils;

public class ApolloUtil {

    private static Config allConfig = ConfigService.getAppConfig();

    public static String getKey(String key) {
        return allConfig.getProperty(key, StringUtils.EMPTY);
    }


}
