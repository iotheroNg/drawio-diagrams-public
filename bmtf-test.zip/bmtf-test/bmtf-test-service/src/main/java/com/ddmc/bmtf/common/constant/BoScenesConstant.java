package com.ddmc.bmtf.common.constant;

public class BoScenesConstant {

    public static final String NORMAL_PRODUCT = "normal_product";
    public static final String GROUP_PRODUCT = "group_product";

    public static final String SHELF_ON = "shelf.on";

    public static final String SHELF_OFF = "shelf.off";
}
