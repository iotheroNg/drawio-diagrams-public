package com.ddmc.bmtf.template.domain.shelf.on;

import com.ddmc.bmtf.constant.DefaultExtPriorityConstant;
import com.ddmc.bmtf.domainimpl.on.StepShelfOnShelf;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

import javax.annotation.Resource;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.SHELF;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;


@ATemplateExt(codes = {SHELF}, scenario = SHELF_ON, type = TemplateType.BUSINESS_OBJECT, templatePriority = DefaultExtPriorityConstant.PRIORITY_COVERED)
public class BoTemplateShelfOnShelf implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFace {
    @Resource
    private StepShelfOnShelf stepShelfOnShelf;
    @Override
    public StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace() {
        return stepShelfOnShelf;
    }
}
