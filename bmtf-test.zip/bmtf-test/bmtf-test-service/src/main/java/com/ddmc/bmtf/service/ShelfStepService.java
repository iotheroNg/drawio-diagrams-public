package com.ddmc.bmtf.service;

import com.ddmc.bmtf.model.execute.BizInstanceId;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.request.ReqWrap;

public interface ShelfStepService {

    void doStep(ReqWrap reqWrap, IBOExeContext bc, BizInstanceId<Object> bizInstanceId);

}
