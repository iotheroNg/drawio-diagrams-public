package com.ddmc.bmtf.template.domain.shelf.on;

import com.ddmc.bmtf.constant.DefaultExtPriorityConstant;
import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domainimpl.on.StepShelfOnBefore;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

import javax.annotation.Resource;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.BEFORE;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;

/**
 * @Description: 前置步骤域模版
 **/
@ATemplateExt(codes = {BEFORE}, scenario = SHELF_ON, type = TemplateType.BUSINESS_OBJECT, templatePriority = DefaultExtPriorityConstant.PRIORITY_COVERED)
public class BoTemplateShelfOnBefore implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFace {

    @Resource
    private StepShelfOnBefore stepShelfOnBefore;

    @Override
    public StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace() {
        return new StepOnOrOffTheShelvesFace() {
            @Override
            public void genBO(ReqWrap reqWrap, IBOExeContext iboExeContext) {
                stepShelfOnBefore.genBO(reqWrap, (ShelfContext) iboExeContext);
            }
        };
    }
}
