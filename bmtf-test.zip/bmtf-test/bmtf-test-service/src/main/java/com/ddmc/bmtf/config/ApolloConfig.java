package com.ddmc.bmtf.config;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;
import org.springframework.context.annotation.Configuration;

@EnableApolloConfig
//@Configuration
public class ApolloConfig {

}
