package com.ddmc.bmtf.template.config;

import com.ddmc.bmtf.common.constant.BoIdentityConstant;
import com.ddmc.bmtf.model.ext.AExtConfig;
import com.ddmc.bmtf.model.ext.AExtExecuteOrder;
import com.ddmc.bmtf.model.ext.IExtConfig;
import com.ddmc.bmtf.model.template.ATU;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.*;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;

/**
 * 业务身份的配置类
 * @description: 模版配置: 1. 配置每个业务身份下场景支持的域模版 2. 配置每个域 执行每一步流程节点的顺序
 */
@AExtConfig(codes = {BoIdentityConstant.DDMC}, supportTemplateCodes = {BoIdentityConstant.DDMC,AFTER, PRODUCT
        , PRICE, PRODUCT, SHELF, BEFORE})
public class BizDDMCExtConfig implements IExtConfig {

    @AExtExecuteOrder(s = SHELF_ON, tus = {
            @ATU(t = AFTER),
            @ATU(t = SHELF),
            @ATU(t = PRICE),
            @ATU(t = STATION),
            @ATU(t = PRODUCT),
            @ATU(t = BEFORE)})
    @Override
    public void boTemplateDefaultExecuteOrderMap() {
    }
}