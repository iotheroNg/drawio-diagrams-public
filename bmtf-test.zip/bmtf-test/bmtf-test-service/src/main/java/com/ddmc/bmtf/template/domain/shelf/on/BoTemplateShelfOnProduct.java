package com.ddmc.bmtf.template.domain.shelf.on;

import com.ddmc.bmtf.constant.DefaultExtPriorityConstant;
import com.ddmc.bmtf.domain.shelf.ShelfContext;
import com.ddmc.bmtf.domain.shelf.ShelfStepShelfBO;
import com.ddmc.bmtf.domainimpl.on.StepShelfOnProduct;
import com.ddmc.bmtf.model.process.IBOExeContext;
import com.ddmc.bmtf.model.process.IBusinessObject;
import com.ddmc.bmtf.model.template.ATemplateExt;
import com.ddmc.bmtf.model.template.IExtensionPointsTemplate;
import com.ddmc.bmtf.model.template.TemplateType;
import com.ddmc.bmtf.request.ReqWrap;
import com.ddmc.bmtf.template.face.shelf.StepGetOnOrOffTheShelvesFace;
import com.ddmc.bmtf.template.step.shelf.StepOnOrOffTheShelvesFace;

import javax.annotation.Resource;

import static com.ddmc.bmtf.common.constant.BoDomainConstant.PRODUCT;
import static com.ddmc.bmtf.common.constant.BoScenesConstant.SHELF_ON;


@ATemplateExt(codes = {PRODUCT}, scenario = SHELF_ON, type = TemplateType.BUSINESS_OBJECT, templatePriority = DefaultExtPriorityConstant.PRIORITY_COVERED)
public class BoTemplateShelfOnProduct implements IExtensionPointsTemplate, StepGetOnOrOffTheShelvesFace {

    @Resource
    private StepShelfOnProduct stepShelfOnProduct;

    @Override
    public StepOnOrOffTheShelvesFace stepOnOrOffTheShelvesFace() {
        return new StepOnOrOffTheShelvesFace() {
            @Override
            public void genBO(ReqWrap reqWrap, IBOExeContext iboExeContext) {
                stepShelfOnProduct.genBO(reqWrap, iboExeContext);
            }

            @Override
            public void checkData(IBusinessObject iBusinessObject, IBOExeContext iboExeContext) {
                stepShelfOnProduct.checkData((ShelfStepShelfBO)iBusinessObject, (ShelfContext)iboExeContext);
            }

            @Override
            public void shelfConfig(IBusinessObject iBusinessObject, IBOExeContext iboExeContext) {
                stepShelfOnProduct.shelfConfig(iBusinessObject, iboExeContext);
            }
        };
    }
}
