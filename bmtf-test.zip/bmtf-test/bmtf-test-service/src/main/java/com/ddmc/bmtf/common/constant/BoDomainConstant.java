package com.ddmc.bmtf.common.constant;

public class BoDomainConstant {
    public static final String BEFORE = "before";

    public static final String AFTER = "after";

    public static final String PRODUCT = "product";

    public static final String PRICE = "price";

    public static final String SHELF = "shelf";

    public static final String STATION = "station";
}
